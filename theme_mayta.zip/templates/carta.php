<?php
	//Template name: Carta
	get_header();
?>

<main>

</main>

<?php
get_footer();
