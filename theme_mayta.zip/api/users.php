<?php

function users_handler()
{
  return ["foo" => "bar"];
}
